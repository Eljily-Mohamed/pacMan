CMAKE_COLOR_DIAGNOSTICS
-----------------------

.. versionadded:: 3.24

.. include:: ENV_VAR.txt

Specifies a default value for the :variable:`CMAKE_COLOR_DIAGNOSTICS` variable
when there is no explicit value given on the first run.
